<?php $__env->startSection('title','TEST PAGE'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>Marks Entry...</h1>
	<h2>Marks Entry for Class: <?php echo e($clsses->cls); ?> and Subject: <?php echo e($subj); ?></h2>
	<br>

	<table class="table table-bordered">
	<tr><th>Name</th><th>Subject</th><th>Th Marks</th><th>Pr Marks</th><th>Total</th><th>Action</th></tr>

	<?php $__currentLoopData = $clsses->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($student->name); ?></td>
			<?php $__currentLoopData = $student->studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>					
				<?php if($study->subject_id != 0 AND $study->subject->subj == $subj): ?>
					<td><?php echo e($study->subject->subj); ?></td>
					<?php $__currentLoopData = $study->marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<td><input type="text" name="" value ="<?php echo e($mark->thmark); ?>"></td>
						<td><input type="text" name="" value ="<?php echo e($mark->prmark); ?>"></td>
						<td><b><?php echo e($mark->thmark+$mark->prmark); ?></b></td>
						<td><button class="btn btn-primary">Save</button></td>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>			

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tr>		
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	</table>
		

	
<?php $__env->stopSection(); ?>





<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>