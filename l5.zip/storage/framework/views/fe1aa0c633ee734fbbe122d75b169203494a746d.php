<?php $__env->startSection('title','REPORT PAGE'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>Result Table ...</h1>
	<table class="table table-bordered">
		<tr>
			<th>Sl</th>
			<th>Name</th>
			<th>Registraion No</th>
			<th>Class Roll No</th>
			<th>Action</th>
		</tr>
		
		<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td></td>
			<td><?php echo e($student->name); ?></td>
			<td><?php echo e($student->reg); ?></td>
			<td><?php echo e($student->roll); ?></td>
			<td><a href="<?php echo e($student->reg); ?>.pdf">Click Me</a>
				

			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>

	<!-- Pagination Starts -->


	<!-- Pagination Ends -->









<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>