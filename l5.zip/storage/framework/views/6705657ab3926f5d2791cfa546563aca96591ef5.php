<?php $__env->startSection('title','Subject Register'); ?>

<?php $__env->startSection('header'); ?>
	
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<center>
			<h1><b>Manikchak High Madrasah(H.S.)</b></h1>
			<h5>Lalgola * Murshidabad</h5>
			<h4><b>Manual Marks Entry Sheet</b><br>for <b>Class XI Annual Exam-2017 Subject: <u><?php echo e($sub); ?></u></b></h4>
</center>

<br>
<table border="1" width="100%" class="" style="font-size:12px;">
	<thead>
		<tr>
			<th>Sl No</th>
			<th>Roll</th>
			<th>Name</th>
			<th>Registration No</th>
			<th>Theory</th>
			<th>Project</th>
			<th>Total</th>
		</tr>
	</thead>
	<tbody>		
			<?php $__currentLoopData = $shreny; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shrn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
				<?php $__currentLoopData = $shrn->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($subject->subj == $sub): ?>
					<?php  $i = 0  ?>
					<?php $__currentLoopData = $subject->studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e(++$i); ?></td>
						<td></td>
						<td><?php echo e($study->student->name); ?></td>
						<td><?php echo e($study->student->reg); ?></td>
						<td></td>
						<td></td>
						<td></td>						
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<!-- <?php $__currentLoopData = $shrn->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td></td>
					<td><?php echo e($student->roll); ?></td>
					<td><?php echo e($student->name); ?></td>
					<td><?php echo e($student->reg); ?></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	 -->
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</tbody>
</table>


<script type="text/php">
    if (isset($pdf)) {
        $x = 250;
        $y = 10;
        $text = "Page {PAGE_NUM} of {PAGE_COUNT}";
        $font = null;
        $size = 14;
        $color = array(255,0,0);
        $word_space = 0.0;  //  default
        $char_space = 0.0;  //  default
        $angle = 0.0;   //  default
        $pdf->page_text($x, $y, $text, $font, $size, $color, $word_space, $char_space, $angle);
    }
</script>








<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
		
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>