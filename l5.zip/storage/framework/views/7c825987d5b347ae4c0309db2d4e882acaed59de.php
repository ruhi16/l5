<?php $__env->startSection('title','TEST PAGE'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>Marks Entry...</h1>
	<h2>Marks Entry for Class: <?php echo e($clsses->cls); ?> and Subject: <?php echo e($subj); ?></h2>
	<br>



	<?php echo Form::open(['url'=>'/addMarks','method'=>'post']); ?>

	<table class="table table-bordered">
	<tr><th>Name</th><th>Subject</th><th>Th Marks</th><th>Pr Marks(<?php echo e($clss); ?>)</th><th>Action</th></tr>

	<?php $__currentLoopData = $clsses->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr><?php $sub=''; $subId=0; ?>
			<td><?php echo e($std->id); ?>:<?php echo e($std->name); ?></td>
			
			<?php $__currentLoopData = $std->studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>				
				<?php if($s->subject_id != 0 AND $s->subject->subj == $subj): ?>				
					<?php 
						$sub   = $s->id.$s->subject->subj; 
						$subId = $s->id; 
					?>					
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php if($sub != ''): ?>
				<td><?php echo e($sub); ?></td>
				<input type="hidden" name="code[]" value="<?php echo e($subId); ?>">
				<td><input type="text" name="Tmark[]" value =""></td>
				<td><input type="text" name="Pmark[]" value =""></td>
				<td><a class="btn btn-info" >Save</a></td>
			<?php else: ?>
				<td></td>	<td></td>	<td></td>	<td></td>
			<?php endif; ?>
			
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	</table>
	<button type="reset" class="btn btn-primary">Reset Fields</button>
	<button type="submit" class="btn btn-warning">Add New Records</button>	
	<?php echo Form::close(); ?>



<script type="text/javascript">
	$(document).ready(function(){
		//alert("Hello");
	});


</script>	
<?php $__env->stopSection(); ?>





<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>