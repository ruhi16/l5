<?php $__env->startSection('title','TEST PAGE'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>COMBINED TEST PAGE ...</h1>
	
<table class="table table-bordered" id="result">
<thead>
<tr><th>Name</th>
	<th colspan="4" class="text-center">Language - I</th>
  <th colspan="4" class="text-center">Language - I</th>
	<th colspan="4" class="text-center">Elective - I</th>
	<th colspan="4" class="text-center">Elective - II</th>
	<th colspan="4" class="text-center">Elective - III</th>
	<th colspan="4" class="text-center">Optional - I</th>
	<th class="text-center">			Total</th>
	<th class="text-center">			Action</th>
</tr>
</thead>

<tbody>
<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
	<?php $index = 0; $total = 0; ?>
  
	<tr id="<?php echo e($student->id); ?>tr">
		<td><?php echo e($student->name); ?><br><small><?php echo e($student->reg); ?></small></td>
			
			<?php $__currentLoopData = $student->studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<td id="<?php echo e($student->id); ?>sub<?php echo e($index); ?>"><?php echo e(isset($study->subject->subj) ? $study->subject->subj : ''); ?></td>
				

				<?php $__empty_1 = true; $__currentLoopData = $study->marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<td id="<?php echo e($student->id); ?>sub<?php echo e($index); ?>th"><?php echo e((int)$mark->thmark); ?></td>
          <td id="<?php echo e($student->id); ?>sub<?php echo e($index); ?>pr"><?php echo e((int)$mark->prmark); ?></td>
          <td id="<?php echo e($student->id); ?>sub<?php echo e($index); ?>to"><?php echo e(($mark->thmark+$mark->prmark)); ?></td>
          <?php $total = $total + ($mark->thmark+$mark->prmark); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <td></td><td></td><td></td>
					
				<?php endif; ?>
				<!-- array_push($old_array, "new value") -->
				
				<?php $index++; ?>
				
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

			
			<?php for($i=0; $i<(6-$index); $i++): ?>
				<td>NA</td>
        <td></td>
        <td></td>
        <td></td>
			<?php endfor; ?>
			<td><b><?php echo e($total); ?></b></td></td>
			<td><a href="<?php echo e(URL::to('/individualStudent')); ?>/<?php echo e($student->id); ?>" class="btn btn-warning">Edit</a></td>
			
	</tr>
	



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>


<script type="text/javascript">
$(document).ready(function(){

  
  // //alert(myArr);
  // $.each(myArr, function(k, v) {
  //   //alert("id" + ' is ' + v.class);
  // });
  


	$('.open-modal').click(function(){ 
		

		  var v = $(this).val();
	    var value = $("#"+v+"tr #"+v+"name").text();
	    var s1 = $("#"+v+"tr #"+v+"sub0").text();
	    var s2 = $("#"+v+"tr #"+v+"sub1").text();
	    var s3 = $("#"+v+"tr #"+v+"sub2").text();
	    var s4 = $("#"+v+"tr #"+v+"sub3").text();
	    var s5 = $("#"+v+"tr #"+v+"sub4").text();
	    var s6 = $("#"+v+"tr #"+v+"sub5").text();
	    //alert($("#19tr #19sub2").text());
	    //alert(s1+s2+s3+s4+s5+s6);
	    //alert(v);
      var i = 0;  var c = [];
      $('table#result').find('tbody').find('tr#'+v+'tr').find('td').each(function(){
        var s = $('td#'+v+'sub'+i).text();
        if(s != ''){
          c.push(s);

          var x = $('td#'+v+'sub'+i+'th').text();
          if(x == '')x=0;
          c.push(x);

          var y = $('td#'+v+'sub'+i+'pr').text();
          if(y == '')y=0;
          c.push(y);          
        }
        i++;
        
        //alert(x+", i:"+i);
        //alert($(this).text());
      });
      for(var j=0; j<c.length; j++){
        if(j%3 == 0){
          $('#myModal #subject'+((j/3)+1)).html(c[j]);
          $('#myModal #subject'+((j/3)+1)+"th").val(c[j+1]);
          $('#myModal #subject'+((j/3)+1)+"pr").val(c[j+2]);

        }
      }
      // $.each(c, function(k,v){
      //   alert(k+" => "+v)
      // });
      //alert(c.length);
      // $.each(c,function(k,v){
      //   alert(k+"=>"+v);
      // });

      if(c.length < 18){
        $('#myModal #subject6').html("NA");
        $("#additional-sub").find("input,select,textarea,button").val(0);
        $("#additional-sub").find("input,select,textarea,button").prop("disabled",true);
      }else{
        $("#additional-sub").find("input,select,textarea,button").prop("disabled",false);
      }
      

		$('#myModal').modal('show');



	});

});
</script>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>