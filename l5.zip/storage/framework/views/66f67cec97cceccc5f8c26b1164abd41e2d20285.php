<?php $__env->startSection('title','REPORT PAGE'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>Result Table ...</h1>
	<table class="table table-bordered">
		<tr>
			<th>Sl</th>
			<th>Name</th>
			<th>Registraion No</th>
			<th>Class Roll No</th>
			<th>Action</th>
		</tr>
		<?php $sl = ($students->currentPage() * 10) - 9; ?>
		<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($sl++); ?></td>
			<td><?php echo e($student->name); ?></td>
			<td><?php echo e($student->reg); ?></td>
			<td><?php echo e($student->roll); ?></td>
			<td>
				<button class="btn btn-primary btn-sm btnGr" data-datac="<?php echo e($student->id); ?>">Get Result</button>

					<a  class="btn btn-info btn-sm dw<?php echo e($student->id); ?> dwn" href="http://localhost/l5/public/<?php echo e($student->reg); ?>.pdf" download>Download</a>

			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>

	<!-- Pagination Starts -->


	<!-- Pagination Ends -->



<div class='pagination'>
	<?php echo e($students->links()); ?>

	<p align='left'><?php echo e($students->total()); ?> students exists.</p>
</div>
	<!-- <?php echo e($students->appends(Request::except('page'))->links()); ?>  -->



	<script type="text/javascript" src="<?php echo e(url('bs337/js/jquery.bootstrap-grow.min.js')); ?>" integrity=""></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('a.dwn').each(function(index) {
    		$(this).hide();
			});



				$('.btnGr').click(function(){
					var x = $(this).data('datac');
					//alert(x);



					var u = '<?php echo e(url("/downloadResult")); ?>';
					var t = '<?php echo e(csrf_token()); ?>';

					var d = $(this).data('datac');
					$("#dwnld").find(".dw"+x).addClass("active");
					$('a.foo.bar[rel="123"]')
					$.ajax({
						method: 'post',
						url: u,
						data: {sid: d, _token: t},
						success: function(msg){
								console.log("ajax Invoked!"+msg['id']+", name:"+msg['name']);
								$.bootstrapGrowl(msg['name']+"'s Result in Pdf, Downloaded Successfully!",{
										type: 'success', // success, error, info, warning
										delay: 3000,
								});

								$('a.dw'+x).show();
						},
						error: function(data){

								$.bootstrapGrowl("Marks are not Updated at All!",{
										type: 'danger', // success, error, info, warning
										delay: 3000,
								});
								console.log("ajax Invoked error!!! occured"+data);
						}
					}); //end of ajax function




				});
		});

	</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>