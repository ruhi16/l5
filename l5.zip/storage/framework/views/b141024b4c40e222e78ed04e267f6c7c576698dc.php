<?php $__env->startSection('title','REPORT PAGE'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>Report's Hub ...</h1>


	<a class="btn btn-primary" href="<?php echo url('/studentResultPdf'); ?>">All Students Result</a>
	<a class="btn btn-warning" href="<?php echo url('/resultTableAll'); ?>">All's Result Table Page</a>
	<a class="btn btn-success" href="<?php echo url('/studentRegisterPdf'); ?>">All Students Register</a>
	<a class="btn btn-info" href="<?php echo url('/studentResultIndPdf'); ?>">Student's Individual Result</a>








<?php $__env->stopSection(); ?>




<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>