<?php $__env->startSection('title','Students Details'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Students Details</h1>
<?php if(session()->has('error')): ?>
	<div class="alert alert-success">
		<strong>Message! <?php echo e(session()->get('error')); ?> </strong>		
	</div>
<?php endif; ?>

<div class="panel panel-default">
  <!-- Default panel contents -->
  <div class="panel-heading">Panel heading</div>

  	<table class="table table-bordered">
    <thead>
      <tr>
        <th>Roll</th>
        <th>Name</th>
        <th>Registraion No</th>
        <th>Subjects Alloted</th>
        <th>Action</th>
      </tr>
    </thead>
    	<tbody>
      
      <tr>
        <td><?php echo e($estud->roll); ?></td>
        <td><?php echo e($estud->name); ?></td>
        <td><?php echo e($estud->reg); ?></td>
        <td>
        <?php $__currentLoopData = $estud->studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($stud->subject_id != 0): ?>
            <?php echo e($stud->subject->subj); ?>, <br>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        <td><button class="btn btn-success btn-lg">Edit</button></td>
      </tr>
      
    	</tbody>
  	</table>

  
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>