<?php $__env->startSection('title','TEST PAGE'); ?>

<?php $__env->startSection('header'); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>Consolidated Students Marks Register ...</h1>
	
<table class="table table-bordered" id="result" style="font-size:10px;">
<thead>
<tr><th>Name</th>
	<th colspan="4" class="text-center">Language - I</th>
  	<th colspan="4" class="text-center">Language - I</th>
	<th colspan="4" class="text-center">Elective - I</th>
	<th colspan="4" class="text-center">Elective - II</th>
	<th colspan="4" class="text-center">Elective - III</th>
	<th colspan="4" class="text-center">Optional - I</th>
	<th class="text-center">			Total</th>
	<th class="text-center">			Remarks</th>
</tr>
</thead>

<tbody>
<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
	<?php $index = 0; $total = 0; ?>
  
	<tr id="<?php echo e($student->id); ?>tr">
		<td><?php echo e($student->name); ?></td>
			
			<?php $__currentLoopData = $student->studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<td id="<?php echo e($student->id); ?>sub<?php echo e($index); ?>"><?php echo e(isset($study->subject->subj) ? $study->subject->subj : ''); ?></td>
				

				<?php $__empty_1 = true; $__currentLoopData = $study->marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<td id="<?php echo e($student->id); ?>sub<?php echo e($index); ?>th"><?php echo e((int)$mark->thmark); ?></td>
          <td id="<?php echo e($student->id); ?>sub<?php echo e($index); ?>pr"><?php echo e((int)$mark->prmark); ?></td>
          <td id="<?php echo e($student->id); ?>sub<?php echo e($index); ?>to"><?php echo e(($mark->thmark+$mark->prmark)); ?></td>
          <?php $total = $total + ($mark->thmark+$mark->prmark); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <td></td><td></td><td></td>
					
				<?php endif; ?>
				
				
				<?php $index++; ?>
				
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

			
			<?php for($i=0; $i<(6-$index); $i++): ?>
				<td>NA</td>
		        <td></td>
		        <td></td>
		        <td></td>
			<?php endfor; ?>
			<td><b><?php echo e($total); ?></b></td></td>
			<td></td>
			
	</tr>
	



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>