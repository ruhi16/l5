    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <a class="navbar-brand" href="<?php echo url('/home'); ?>">Home Page</a>
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li><a href="<?php echo url('/dashboard'); ?>">Dashboard</a></li> <!-- class="active" -->
            <li><a href="<?php echo url('/students'); ?>">Students</a></li> <!-- class="active" -->
            <li><a href="<?php echo url('/subject'); ?>">Subjects</a></li>
            <li><a href="<?php echo url('/classDetails'); ?>">Classes</a></li>
            <li><a href="<?php echo url('/test2'); ?>">Stu-Sub-Marks</a></li>
            <li><a href="<?php echo url('/test'); ?>">Marks Entry</a></li>            
            <li><a href="<?php echo url('/reportDetails'); ?>">Reports</a></li>
            <li><a href="<?php echo url('/selectSubjectPdf'); ?>">Pdf Subject</a></li>
            <li><a href="<?php echo url('/studentRoll'); ?>">Update Student Roll </a></li>
          </ul>

          <?php if(session()->has('user')): ?>
              <ul class="nav navbar-nav navbar-right">
                <li><p class="navbar-brand"><small>Welcome, <?php echo session()->get('user'); ?></small></p></li>
                <li><a href="<?php echo e(url('/logout')); ?>"><span class="glyphicon glyphicon-log-out"></span>Log Out</a></li>
              </ul>
          <?php else: ?>
              <ul class="nav navbar-nav navbar-right">
                <li><a href="<?php echo url('/register'); ?>"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                <li><a href="<?php echo url('/login'); ?>"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
              </ul>
          <?php endif; ?>
      </div>
      </div>
    </nav>