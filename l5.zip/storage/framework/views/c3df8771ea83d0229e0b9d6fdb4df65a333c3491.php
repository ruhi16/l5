<!DOCTYPE html>
<html>
<head>
    <!-- <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title page-title></title>
    <link href='https://app.dayjibe.com/app/styles/fonts.googleapis.css' rel='stylesheet' type='text/css'>
    <link href="css/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://app.dayjibe.com/app/styles/style.css" rel="stylesheet"> -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title page-title></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bs337/css/bootstrap.min.css')); ?>" >
    <script src="<?php echo e(url('jQ/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('bs337/js/bootstrap.min.js')); ?>" integrity=""></script>
</head>
<body class="bodyopacity" landing-scrollspy id="page-top">
<!-- Main view  -->


	<center><h1><b>Manikchak High Madrasah(H.S.)</b></h1>
    <h4>Lalgola * Murshidabad</h4>
    <b>Progress Report</b> for <b>Class XI Annual Exam-2017</b></center>

    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e(qrTest($student->reg, $student->name)); ?>

    <table width='100%'><tr><td>
        <td><h3>Name: <?php echo e($student->name); ?> [Class Roll: <?php echo e($student->roll); ?> ]</h3>
        <h4>Registration No: <?php echo e($student->reg); ?></h4></td>
        <td><div class='col-xs-4'><center><img src='<?php echo e($student->reg); ?>.png'></center></div></td></tr>
    </table>
    <!-- <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->



	<table class="table table-bordered">
		<tr>
			<th>Subject</th>
			<th>Theory</th>
			<th>Practical</th>
			<th>Total</th>
		</tr>
		<!-- <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> -->
		<tr>
			<td><?php echo e($student->subj); ?></td>
			<td><?php echo e((int)$student->thmark); ?></td>
			<td><?php echo e((int)$student->prmark); ?></td>
			<td><?php echo e($student->thmark+$student->prmark); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>


</body>
</html>
