<?php $__env->startSection('title','TEST PAGE'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>	
	<h2>Marks Entry for Class: <?php echo e($clss); ?> and Subject:<em> <?php echo e($subj); ?></em></h2>
	


<h3>Total Students: <?php echo e($test->total()); ?></h3>
<h6>This Page Contain Students, from <b><?php echo e(($test->currentPage()-1)*20+1); ?></b> to <b><?php echo e(($test->currentPage()-1)*20+$test->count()); ?></b> </h6>

<table class="table table-bordered" id="marks">
<thead>
	<tr>
		<th>Sl No</th>
		<th>Name</th>
		<th>Reg. No</th>
		<th>Th Marks</th>
		<th>Pr Marks</th>
		<th>Total</th>
		<th>Action</th>
	</tr>
</thead>
<?php $i = ($test->currentPage()-1)*20;?>
<?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tbody>
	<tr id="<?php echo e($t->reg); ?>">
		<td id="stid" class="text-center"><input type="hidden" name="stid" id="sid" value="<?php echo e($t->sid); ?>"><?php echo e(++$i); ?></td>
		<td><?php echo e($t->name); ?></td>
		<td><?php echo e($t->reg); ?></td>
		<td id="thmr"><input type="text" class="form-control input-sm" name="thmr" id="thm" value="<?php echo e(isset($t->thmark) ? $t->thmark : ''); ?>"></td>
		<td id="prmr"><input type="text" class="form-control input-sm" name="prmr" id="prm" value="<?php echo e(isset($t->prmark) ? $t->prmark : ''); ?>"></td>
		<td></td>
		<td id="action">
			<?php if(isset($t->thmark)): ?>
				<button class="btn btn-success" data-datac="<?php echo e($t->reg); ?>">Update</button>
			<?php else: ?>
				<button class="btn btn-primary" data-datac="<?php echo e($t->reg); ?>">Save</button>
			
			<?php endif; ?>
		</td>		
	</tr>
	</tbody>	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>







<?php
// config
$link_limit = 9; // maximum number of links (a little bit inaccurate, but will be ok for now)
?>
<?php if($test->lastPage() > 1): ?>
    <ul class="pagination">
    	<!-- if the current page is 1, first page -->
        <li class="<?php echo e(($test->currentPage() == 1) ? ' disabled' : ''); ?>">
        <?php   $x = $test->url(1); $a = explode('?', $x); $y = $a[0].'?cls='.$clss.'&sub='.$subj.'&'.$a[1]; //echo $y;  ?>
            <a href="<?php echo e($y); ?>">First</a>
         </li>
         <!--  -->
        <?php for($i = 1; $i <= $test->lastPage(); $i++): ?>
            <?php
            $half_total_links = floor($link_limit / 2);
            $from = $test->currentPage() - $half_total_links;
            $to   = $test->currentPage() + $half_total_links;
            if ($test->currentPage() < $half_total_links) {
               $to += $half_total_links - $test->currentPage();
            }
            if ($test->lastPage() - $test->currentPage() < $half_total_links) {
                $from -= $half_total_links - ($test->lastPage() - $test->currentPage()) - 1;
            }
            ?>
            <?php if($from < $i && $i < $to): ?>
                <li class="<?php echo e(($test->currentPage() == $i) ? ' active' : ''); ?>">
                <?php   $x = $test->url($i); $a = explode('?', $x); $y = $a[0].'?cls='.$clss.'&sub='.$subj.'&'.$a[1]; //echo $y;  ?>
                    <a href="<?php echo e($y); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endif; ?>
        <?php endfor; ?>
        <!-- if the current page is 1, first page -->
        <li class="<?php echo e(($test->currentPage() == $test->lastPage()) ? ' disabled' : ''); ?>">
        <?php   $x = $test->url($test->lastPage()); $a = explode('?', $x); $y = $a[0].'?cls='.$clss.'&sub='.$subj.'&'.$a[1]; //echo $y;  ?>
            <a href="<?php echo e($y); ?>">Last</a>
        </li>
        <!--  -->
    </ul>
<?php endif; ?>

<!-- <?php echo e($test->links()); ?> -->











<script type="text/javascript">
	$(document).ready(function(){
		var si;
		var th;
		var pr;

		$('.btn').click(function() {
			var d = $(this).data('datac'); //collect the student registration no from 'data-datac' property
			si = $('#marks #'+d+' #stid #sid').val();
			th = $('#marks #'+d+' #thmr #thm').val();
			pr = $('#marks #'+d+' #prmr #prm').val();
      		//var d = $(this).data('datac');#marks #12345 #name 
      		if(th == '') th = 0;     
      		if(pr == '') pr = 0;
      		//alert("#marks #"+d+" #action");
      		//alert(si+th+pr);   
		


			var u = '<?php echo e(url("/AddSubMrk")); ?>';
			var t = '<?php echo e(csrf_token()); ?>';

	 		$.ajax({
		      	method:'post',
		      	url: u,      
		      	data: {sid: si, thm: th, prm: pr, _token: t},
		      	success: function(msg){	    	
		            console.log(msg['oval']+"XX"+msg['nval']);

		            $("#marks #"+d+" #action").html("<button class='btn btn-success' data-datac='"+d+"'>Update</button>");
		    	},
		    	error: function (data) {
	                console.log('Error:', data);
	            }
		    }); //end of ajax 

		}); // end of button click function
	}); //end of document ready function

	

</script>	
<?php $__env->stopSection(); ?>





<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>