<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('header'); ?>
	
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php  $gTotal = 0;  ?>
	<div class="row">
		<div class="col-xs-12 text-center">
			<h1><b>Manikchak High Madrasah(H.S.)</b></h1>
			<h4>Lalgola * Murshidabad</h4>
			<b>Progress Report</b> for <b>Class XI Annual Exam-2017</b>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-8 text-left">			
			<div class="row">
				<div class="col-xs-12">
					<br><br>
					<p><h4>Name: <?php echo e($student->name); ?><small>[Class Roll:<?php echo e($student->roll); ?>]</small></h4></p>
					<p> Registration No: <?php echo e($student->reg); ?></p>
				</div>
			</div>
		</div>
		<div class="col-xs-4">
			<img src="qrcode.png">
		</div>				
	</div>
		<table class="table table-bordered text-center tabel-sm" style="font-size:12px;">
			<tr>
				<th rowspan="2"></th>
				<th rowspan="2" class="text-center">Subject</th>
				<th colspan="2" class="text-center">Full Marks</th>
				<th colspan="2" class="text-center">Pass Marks</th>
				<th colspan="3" class="text-center">Obtained Marks</th>
				<th rowspan="2" class="text-center">Grade</th>
			</tr>
			<tr>

				<th class="text-center">Theory</th>
				<th class="text-center">Project</th>
				<th class="text-center">Theory</th>
				<th class="text-center">Project</th>
				<th class="text-center">Theory</th>
				<th class="text-center">Project</th>
				<th class="text-center">Total</th>
			</tr>
		<?php $__empty_1 = true; $__currentLoopData = $student->studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<tr>
				<td rowspan="2"></td>
				<td rowspan="2" class="text-left"><?php echo e(isset($study->subject->subj) ? $study->subject->subj : 'Not Assigned'); ?></td>
				<td rowspan="2"><?php echo e(isset($study->subject->fmTh) ? $study->subject->fmTh : ''); ?></td>
				<td rowspan="2"><?php echo e(isset($study->subject->fmPr) ? $study->subject->fmPr : ''); ?></td>
				<td rowspan="2"><?php echo e(isset($study->subject->pmTh) ? $study->subject->pmTh : ''); ?></td>
				<td rowspan="2"><?php echo e(isset($study->subject->pmPr) ? $study->subject->pmPr : ''); ?></td>
				<?php $__empty_2 = true; $__currentLoopData = $study->marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
					<td><?php echo e((int)$mark->thmark); ?></td>
					<td><?php echo e((int)$mark->prmark); ?></td>
					<td><?php echo e(($mark->thmark+$mark->prmark)); ?></td>
					<td rowspan="2">
						
					</td>
					<?php  $gTotal += ($mark->thmark+$mark->prmark);  ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
					<td></td><td></td><td></td><td rowspan="2"></td>
				<?php endif; ?>
			</tr>
			<tr>
				<td colspan="3">Eighty Seven</td>
			</tr>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<td>Data Not Found</td>
		<?php endif; ?>
		<tr class="text-left">
			<td colspan="6"><b>Overall Result: <br>Grade:</b></td>
			<td colspan="2"><b>Grand Ttotla</b></td>
			<td class="text-center"><b><?php echo e($gTotal); ?></b></td>
			<td class="text-center"><b><?php echo e($gTotal/5); ?>%</b></td>
		</tr>

		</table>



<br><br>


<table class="table">
	<thead>
		<th class="text-center">Class Teacher</th>
		<th class="text-center">Head of the Institution</th>		
	</thead>
	<tbody>
		
	</tbody>
</table>


<table class="table table-bordered" style="font-size:10px;">
	<thead>
		<tr>
		<th colspan="8" class="text-center">		
		Subjec-wise marks and grade are shown in the Mark Sheet. Classification of Grade is given bellow:		
		</th>
		</tr>
	</thead>

	<tbody class="text-center">
	<tr>
		<td>90-100:O [Outstanding]</td>
		<td>88-89: A+ [Excelent]</td>
		<td>70-79: A [Very Good]</td>
		<td>60-69: B+ [Good]</td>
		<td>50-59: B [Satisfactory]</td>
		<td>40-49: C [Fair]</td>
		<td>30-39: P [Passed]</td>
		<td>Bellow 39: F [Failed]</td>
	</tr>
	</tbody>
</table>


<div style="page-break-after:always;"></div> 
<?php break; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>










<?php $__env->startSection('footer'); ?>
		
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>