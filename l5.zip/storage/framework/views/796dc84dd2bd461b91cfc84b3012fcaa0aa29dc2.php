<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<?php echo $__env->make('layouts.supports', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>


<div class="container-fluid">
<?php $__env->startSection('header'); ?>

	<!-- <header>This is Base-header Section</header> -->
<?php echo $__env->yieldSection(); ?>
</div>
<?php $__env->startSection('main'); ?>
	<div class="container">
		<?php echo $__env->yieldContent('content'); ?>
	</div>
<?php echo $__env->yieldSection(); ?>

<?php $__env->startSection('footer'); ?>
	<div class="container">
		<footer>This is base-footer Section</footer>
	</div>
<?php echo $__env->yieldSection(); ?>
</body>