<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php echo Form::open(['url' => 'foo/bar']); ?>

    echo Form::token();
<?php echo Form::close(); ?>

</body>
</html>