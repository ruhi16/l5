<?php $__env->startSection('title','TEST PAGE'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>TEST PAGE ...</h1>
	<?php echo Form::open(['url'=>'/selectSubject','method'=>'get']); ?>

	<div class="row">
		<div class="form-group">
    		<label class="col-sm-2 text-right" for="cls">Class:</label>
    		<div class="col-sm-3">
    			<select class="form-control" name="cls">
    				<option> </option>
    				<?php $__currentLoopData = $clss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cls->id); ?>"><?php echo e($cls->cls); ?></option>                  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			</select>
    		</div>

    		<label class="col-sm-1 text-right" for="cls">Subject:</label>
    		<div class="col-sm-3">
    			<select class="form-control" name="sub">
                    <option value="0"></option>
                    <?php $__currentLoopData = $subjs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    				    <option value="<?php echo e($sub->subj); ?>"><?php echo e($sub->subj); ?></option>    				
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    			</select>
    		</div>

    		<div class="col-sm-2">
    			<input type="submit" class="form-control btn btn-success" id="" value="Submit">
    		</div>
  		</div>
	</div>
	<?php echo Form::close(); ?>


	<br>
	<hr>
	<br>
	


	


<?php $__env->stopSection(); ?>





<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>