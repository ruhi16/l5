<?php $__env->startSection('title','Home Page'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session()->has('error')): ?>
	<div class="alert alert-success">
		<strong>Message! <?php echo e(session()->get('error')); ?></strong>
		<?php echo e(session()->forget('error')); ?>

		
	</div>
<?php endif; ?>

	<div class="container">
      <div class="jumbotron">
        <h1>Home Page</h1>
        <p class="lead">This is a intermediatery example of Class XI Result Automation System. The full & Completed version will be arrived soon...</p>
        <a class="btn btn-lg btn-primary" href="#" role="button">View navbar docs &raquo;</a>
      </div>
    </div>

Subject Wise Students List:
<table class="table table-bordered">
<?php $__currentLoopData = $shrenies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shreny): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
	<?php $__currentLoopData = $shreny->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<tr>
		<td><?php echo e($subject->subj); ?></td>
		<?php  $count = 0;  ?>
		<td>
		<?php $__currentLoopData = $subject->studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
			<?php  $count++;  ?>	
			<?php echo e($study->student->name); ?>, 	
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		</td>
		<td><?php echo e($count); ?></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

Student Wise Subjects List:
<table class="table table-bordered">
<?php $__currentLoopData = $shrenies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shreny): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
	<?php $__currentLoopData = $shreny->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<tr>
		<td><?php echo e($student->name); ?></td>
		<?php  $count = 0;  ?>
		<td>
		<?php $__currentLoopData = $student->studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
			<?php if(isset($study->subject->subj)): ?>
				<?php  $count++;  ?>	
			<?php endif; ?>
			<td><?php echo e(isset($study->subject->subj) ? $study->subject->subj : ''); ?></td>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		</td>
		<td><?php echo e($count); ?></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>