<?php $__env->startSection('title','Subject Selection'); ?>

<?php $__env->startSection('header'); ?>
	<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>Subject Selection ...</h1>
<div class="form-group">
  <label for="sel1">Select list:</label>
  <select class="form-control" id="sel1">
    <option>1</option>
    <option>2</option>
    <option>3</option>
    <option>4</option>
  </select>
</div>	



<?php $__env->stopSection(); ?>





<?php $__env->startSection('footer'); ?>
	<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.baselayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>