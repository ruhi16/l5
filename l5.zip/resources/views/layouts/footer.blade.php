	<footer class="navbar-bottom">
	  <div class="panel panel-default">
	    <div class="panel-body text-center">basic footer</div>
	  </div>
	</footer>
