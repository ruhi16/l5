@extends('layouts.baselayout')
@section('title','Home Page')

@section('header')
	@include('layouts.navbar')
@endsection

@section('content')

<img src="qrcode.png" alt="Sorry">


@endsection


@section('footer')
	@include('layouts.footer')
@endsection
