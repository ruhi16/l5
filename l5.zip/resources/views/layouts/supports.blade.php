	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" type="text/css" href="{{url('bs337/css/bootstrap.min.css')}}" >
    <script src="{{url('jQ/jquery.min.js')}}"></script>
    <script src="{{url('bs337/js/bootstrap.min.js')}}" integrity=""></script>


